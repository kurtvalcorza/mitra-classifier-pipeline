"""Review probes for mitra-classifier-pipeline v1 FreshRetailNet classification workshop (FRC1).

Reviewed revision: 0434a026cf755071e89bc33c876e67040c2a614d
Notebook: tutorials/DIMER_FreshRetailNet_MultiModel_Classification_Workshop.ipynb (blob 6b8986df)

Usage: python run_probes.py <exported_repo_root> [<projects_root>]
Direct execution is local Windows CPU (Python 3.12, numpy 2.5.2, pandas 3.0.5, scikit-learn 1.9.0,
lightgbm 4.6.0). No foundation model is executed. Cells are executed from the notebook's own source;
form fields are changed only by rewriting their literal assignment line (as an EXE6 executor would).
"""
from __future__ import annotations

import ast
import hashlib
import io
import json
import os
import re
import shutil
import sys
import tempfile
import traceback
import zipfile
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

REPO = Path(sys.argv[1] if len(sys.argv) > 1 else "src").resolve()
PROJECTS = Path(sys.argv[2]) if len(sys.argv) > 2 else None
NB_REL = "tutorials/DIMER_FreshRetailNet_MultiModel_Classification_Workshop.ipynb"
LEGACY_REL = "docs/execution-evidence/2026-09-26/legacy-classification-saved-outputs.ipynb"
NB = json.loads((REPO / NB_REL).read_text(encoding="utf-8"))
CELLS = ["".join(c["source"]) for c in NB["cells"]]
RESULTS: dict[str, dict] = {}


def cell(i: int) -> str:
    return CELLS[i]


def set_field(src: str, name: str, value_literal: str) -> str:
    pattern = re.compile(rf"^{name} = .*?(# @param.*)?$", re.M)
    if not pattern.search(src):
        raise KeyError(f"field {name} not found")  # EXE6: fail when a field is missing
    return pattern.sub(lambda m: f"{name} = {value_literal} {m.group(1) or ''}".rstrip(), src, count=1)


def record(pid: str, **kw):
    RESULTS[pid] = kw
    print(f"[{pid}] {kw.get('verdict')}: {kw.get('summary')}")


def fresh_namespace(workdir: Path) -> dict:
    os.chdir(workdir)
    ns: dict = {"__name__": "__probe__"}
    exec(compile(cell(6), "cell6", "exec"), ns)  # imports, helpers, session dirs under cwd
    ns["display"] = lambda *a, **k: None
    return ns


def make_zip(path: Path, members: dict[str, bytes]):
    with zipfile.ZipFile(path, "w") as zf:
        for name, data in members.items():
            zf.writestr(name, data)


def sample_members() -> dict[str, bytes]:
    with zipfile.ZipFile(REPO / "examples/sample-data/freshretailnet-band-h7.zip") as zf:
        return {n: zf.read(n) for n in zf.namelist() if n.endswith(".csv")}


# P01 legacy saved-output evidence binds to the same source ---------------------------------
def p01():
    legacy = json.loads((REPO / LEGACY_REL).read_text(encoding="utf-8"))
    diffs = [i for i, (a, b) in enumerate(zip(NB["cells"], legacy["cells"]))
             if "".join(a["source"]) != "".join(b["source"]) or a["cell_type"] != b["cell_type"]]
    code = [c for c in legacy["cells"] if c["cell_type"] == "code"]
    counts = [c.get("execution_count") for c in code]
    errors = [o.get("ename") for c in code for o in c.get("outputs", []) if o["output_type"] == "error"]
    text = json.dumps(legacy)
    record(
        "P01_legacy_evidence",
        verdict="observed",
        summary=f"cell diffs={len(diffs)}; exec counts linear={counts == list(range(1, len(code)+1))}; "
                f"errors={len(errors)}; 4/4 success line={'Successful foundation-model runs: 4 / 4' in text}; "
                f"run-all-complete line={'Run-all complete' in text}",
        cell_diffs=diffs, n_cells=(len(NB['cells']), len(legacy['cells'])), execution_counts=counts,
        errors=errors, gpu_type=legacy["metadata"].get("colab", {}).get("gpuType"),
        recorded_commit_or_date_in_metadata=False,
        basis="documented execution evidence (saved outputs; no recorded commit/date/executor)",
    )


# P02 carried adapters vs pinned upstream ----------------------------------------------------
def p02():
    if PROJECTS is None:
        record("P02_carried_fidelity", verdict="not run", summary="no projects root supplied")
        return
    import subprocess
    src20 = cell(20)
    tree = ast.parse(src20)
    carried = next(ast.literal_eval(n.value) for n in tree.body
                   if isinstance(n, ast.Assign) and getattr(n.targets[0], "id", "") == "CARRIED_ADAPTER_SOURCES")
    pins = {"mitra_pipeline": ("mitra-classifier-pipeline", "469d91252f3583b38d08b5c4d90fef4848b93f24", ""),
            "tabdpt_classifier_pipeline": ("tabdpt-classifier-pipeline", "1e35dc4738f015b254b1724fd4bc7ba9f49668af", "src/"),
            "tabpfn_classifier_pipeline": ("tabpfn-classifier-pipeline", "769fb7b47e01b1d10edd954dabc634b8034598c2", "src/"),
            "tabicl_classifier_pipeline": ("tabicl-classifier-pipeline", "7400516ac86e3b6e55f5134ad5e550f312948981", "src/")}
    out = {}
    for rel, text in carried.items():
        if rel.endswith("__init__.py"):
            out[rel] = f"package marker, {len(text)} chars"
            continue
        repo, commit, prefix = pins[rel.split("/")[0]]
        r = subprocess.run(["git", "-C", str(PROJECTS / repo), "show", f"{commit}:{prefix}{rel}"], capture_output=True)
        out[rel] = "IDENTICAL" if r.returncode == 0 and r.stdout.decode() == text else "DIFF_or_missing"
    ok = all(v == "IDENTICAL" for k, v in out.items() if not k.endswith("__init__.py"))
    record("P02_carried_fidelity", verdict="pass" if ok else "fail",
           summary=f"{sum(v == 'IDENTICAL' for v in out.values())} modules byte-identical to pinned upstream",
           detail=out, basis="source inspection against local clones at pinned commits")


# P03 acquisition retry safety (cell 8) ------------------------------------------------------
def p03():
    work = Path(tempfile.mkdtemp(prefix="frc1_p03_"))
    ns = fresh_namespace(work)
    members = sample_members()
    bad = work / "bad.zip"
    good = work / "good.zip"
    make_zip(bad, {k: v for k, v in members.items() if k != "test.csv"})
    make_zip(good, members)
    steps = []

    def run(zip_path: Path, label: str):
        src = set_field(cell(8), "USE_BYOD", "True")
        src = set_field(src, "BYOD_ZIP_PATH", repr(str(zip_path)))
        try:
            exec(compile(src, "cell8", "exec"), ns)
            steps.append({"step": label, "outcome": "ok"})
        except Exception as exc:  # noqa: BLE001
            steps.append({"step": label, "outcome": f"{type(exc).__name__}: {str(exc)[:160]}"})

    run(bad, "1 BYOD ZIP missing test.csv")
    run(good, "2 corrected ZIP, same session")
    ns2 = fresh_namespace(Path(tempfile.mkdtemp(prefix="frc1_p03b_")))
    ns.clear(); ns.update(ns2)
    run(good, "3 first valid acquisition in a fresh session")
    run(good, "4 repeat the same acquisition")
    blocked = [s for s in steps if s["outcome"].startswith("FileExistsError")]
    record("P03_acquisition_retry", verdict="fail" if blocked else "pass",
           summary=f"{len(blocked)} of 4 steps blocked by FileExistsError", steps=steps,
           basis="direct execution of cell 1.1 source, local CPU, BYOD path field")


# P04 baseline ladder: direct CPU run + rerun safety (cell 16) -----------------------------------
def p04():
    work = Path(tempfile.mkdtemp(prefix="frc1_p04_"))
    ns = fresh_namespace(work)
    zp = work / "sample.zip"
    make_zip(zp, sample_members())
    src8 = set_field(set_field(cell(8), "USE_BYOD", "True"), "BYOD_ZIP_PATH", repr(str(zp)))
    for i, s in ((8, src8), (10, cell(10)), (12, cell(12)), (14, cell(14)), (16, cell(16))):
        exec(compile(s, f"cell{i}", "exec"), ns)
    table = ns["baseline_validation_results"][["model_key", "balanced_accuracy", "log_loss"]]
    observed = {r.model_key: round(r.balanced_accuracy, 4) for r in table.itertuples()}
    legacy = {"random_forest": 0.5733, "logistic_regression": 0.5707, "lightgbm": 0.5426,
              "lag7_quantile_band": 0.5086, "training_prior_majority": 0.3333}
    globals()["LAG7_PRED"] = ns["baseline_prediction_registry"]["lag7_quantile_band"].copy()
    before = sorted(ns["baseline_prediction_registry"])
    try:
        exec(compile(cell(16), "cell16-rerun", "exec"), ns)
        rerun = "ok"
    except Exception as exc:  # noqa: BLE001
        rerun = f"{type(exc).__name__}: {str(exc)[:160]}"
    after = sorted(ns["baseline_prediction_registry"])
    RESULTS["P04_registry_after_failed_rerun"] = {"verdict": "observed",
        "summary": f"baseline_prediction_registry keys before={len(before)}, after failed rerun={len(after)}",
        "basis": "direct execution, local CPU"}
    # keep namespace for later probes
    RESULTS["_ns_p04"] = {"workdir": str(work)}
    globals()["NS_P04"] = ns
    record("P04_baselines_and_rerun", verdict="fail" if rerun != "ok" else "pass",
           summary=f"rerun of 4.1 -> {rerun}; validation BA matches legacy saved outputs: "
                   f"{all(abs(observed[k]-v) < 0.01 for k, v in legacy.items())}",
           observed_val_balanced_accuracy=observed, legacy_saved=legacy, rerun_outcome=rerun,
           basis="direct execution, local CPU (host libs differ from Colab)")


# P05 TabICL ablation silently drops fine-tuning ---------------------------------------------
def p05():
    tree = ast.parse(cell(22))
    runner = next(ast.literal_eval(n.value) for n in tree.body
                  if isinstance(n, ast.Assign) and getattr(n.targets[0], "id", "") == "RUNNER_SOURCE")
    has_exact = 'if config["condition"] == "fine_tuned":' in runner
    mode_exact = '"fine_tuned" if config["condition"] == "fine_tuned" else "in_context"' in runner
    formula = 'condition_override=CONDITION_SPECS[base_key]["condition"] + "_" + FOUNDATION_ABLATION_GROUP' in cell(29)
    rows = []
    for base in ("in_context", "fine_tuned"):
        for group in ("no_stockout", "no_period_proxies"):
            cond = base + "_" + group
            rows.append({"base": base, "ablated_condition": cond,
                         "runner_takes_finetune_branch": cond == "fine_tuned"})
    broken = [r for r in rows if r["base"] == "fine_tuned" and not r["runner_takes_finetune_branch"]]
    record("P05_tabicl_ablation_mode", verdict="fail" if (has_exact and formula and broken) else "pass",
           summary=f"runner exact-match predicate={has_exact}, effective_mode exact-match={mode_exact}, "
                   f"cell 7.1 suffix formula={formula}; fine-tuned ablations falling to in-context: {len(broken)}/2",
           rows=rows, basis="source inspection + reduced dispatch reproduction (no GPU run)")


# P06 frozen test config built from live notebook state --------------------------------------
def p06():
    src = cell(32)
    live = '"model_configuration": spec["configuration"]' in src and 'spec = CONDITION_SPECS[key]' in src
    tree = ast.parse(cell(22))
    runner = next(ast.literal_eval(n.value) for n in tree.body
                  if isinstance(n, ast.Assign) and getattr(n.targets[0], "id", "") == "RUNNER_SOURCE")
    consumed = 'settings = config["model_configuration"]' in runner.split("def run_test")[1].split("def execute")[0]
    # reduced reproduction: the frozen dev file says 4 ensembles; live spec says 8
    frozen_dev = {"model_configuration": {"n_ensembles": 4}}
    live_specs = {"tabdpt_icl": {"configuration": {"n_ensembles": 8}}}
    test_cfg = {"model_configuration": live_specs["tabdpt_icl"]["configuration"]}
    record("P06_freeze_binding", verdict="fail" if live and consumed else "pass",
           summary=f"8.1 builds test config from live CONDITION_SPECS={live}; run_test consumes it={consumed}; "
                   f"reduced repro: frozen n_ensembles={frozen_dev['model_configuration']['n_ensembles']}, "
                   f"test uses {test_cfg['model_configuration']['n_ensembles']}",
           refreeze_guard=("FREEZE_PATH.exists()" in cell(31)),
           basis="source inspection + reduced control-flow reproduction")


# P07 data periods and test class balance (reviewer-only, post hoc) ----------------------------
def p07():
    import pandas as pd
    m = sample_members()
    frames = {k[:-4]: pd.read_csv(io.BytesIO(v)) for k, v in m.items()}
    months = {k: sorted(map(int, f["month"].unique())) for k, f in frames.items()}
    balance = {k: f["target"].value_counts(normalize=True).round(4).to_dict() for k, f in frames.items()}
    claim_ok = months.get("train") == [4, 5] and months.get("val") == [5] and months.get("test") == [6]
    record("P07_periods_and_balance", verdict="pass" if claim_ok else "fail",
           summary=f"months by split={months} (cell 7 claim: train Apr-May, val May, test June)",
           months=months, class_balance=balance, basis="direct inspection of pinned sample ZIP")


# P08 lag-7 heuristic log loss is set by its epsilon -------------------------------------------
def p08():
    import numpy as np
    from sklearn.metrics import log_loss
    ns = globals().get("NS_P04")
    if ns is None:
        record("P08_lag7_logloss", verdict="not run", summary="P04 namespace missing")
        return
    pred = globals()["LAG7_PRED"]
    y = pred["target"].map({c: i for i, c in enumerate(ns["CLASS_LABELS"])}).to_numpy()
    ids = pred[[f"probability_{c}" for c in ns["CLASS_LABELS"]]].to_numpy().argmax(axis=1)
    out = {}
    for eps in (1e-6, 1e-3, 0.05, 0.2):
        p = np.full((len(ids), 3), eps)
        p[np.arange(len(ids)), ids] = 1 - 2 * eps
        out[str(eps)] = round(float(log_loss(y, p, labels=[0, 1, 2])), 4)
    record("P08_lag7_logloss", verdict="observed",
           summary=f"lag-7 heuristic validation log loss by epsilon: {out} (notebook uses 1e-6, unexplained)",
           detail=out, basis="direct execution, local CPU")


# P09 BYOD invalid inputs: rejection messages (cell 10) ---------------------------------------
def p09():
    import pandas as pd
    cases = {}
    base = sample_members()
    def relabel(data: bytes) -> bytes:
        df = pd.read_csv(io.BytesIO(data))
        df["target"] = df["target"].map({"low": "A", "mid": "B", "high": "C"})
        return df.to_csv(index=False).encode()
    def reorder(data: bytes) -> bytes:
        df = pd.read_csv(io.BytesIO(data))
        cols = list(df.columns); cols[0], cols[1] = cols[1], cols[0]
        return df[cols].to_csv(index=False).encode()
    variants = {"other_class_names": {k: relabel(v) for k, v in base.items()},
                "reordered_columns": {k: reorder(v) for k, v in base.items()}}
    for name, members in variants.items():
        work = Path(tempfile.mkdtemp(prefix=f"frc1_p09_{name}_"))
        ns = fresh_namespace(work)
        zp = work / "byod.zip"
        make_zip(zp, members)
        src8 = set_field(set_field(cell(8), "USE_BYOD", "True"), "BYOD_ZIP_PATH", repr(str(zp)))
        try:
            exec(compile(src8, "cell8", "exec"), ns)
            exec(compile(cell(10), "cell10", "exec"), ns)
            cases[name] = "accepted"
        except Exception as exc:  # noqa: BLE001
            cases[name] = f"{type(exc).__name__}: {str(exc)[:220]}"
    stated = "low" in cell(4) and "mid" in cell(4)
    record("P09_byod_rejections", verdict="observed",
           summary=f"{cases}; class-label rule stated in BYOD prose (cell 4)={stated}",
           cases=cases, basis="direct execution of cells 1.1 + 2.1, local CPU")


# P10 export bundle contents (static) ---------------------------------------------------------
def p10():
    src = cell(40)
    record("P10_export_contents", verdict="observed",
           summary="export writes aggregate CSVs, freeze.json, figures, manifest, inference preview; "
                   f"per-row validation/test predictions copied={'predictions.csv' in src and 'copy' in src}; "
                   f"run_config copied={'run_config' in src}; notebook commit/blob recorded={'commit' in src.lower()}",
           basis="source inspection")


# P11 host dependency control (static) --------------------------------------------------------
def p11():
    src = cell(6)
    record("P11_host_pins", verdict="observed",
           summary=f"lightgbm pinned only if absent={'find_spec(\"lightgbm\") is None' in src}; "
                   f"numpy/pandas/sklearn/matplotlib version check present={'tested' in src.lower() or 'TESTED' in src}",
           basis="source inspection")


# P12 tutorials/README.md guidance on v1 vs v2 ------------------------------------------------
def p12():
    readme = (REPO / "tutorials/README.md").read_text(encoding="utf-8")
    v2 = json.loads((REPO / "tutorials/DIMER_FreshRetailNet_MultiModel_Classification_Workshop_v2.ipynb").read_text(encoding="utf-8"))
    v2_outputs = sum(1 for c in v2["cells"] if c["cell_type"] == "code" and c.get("outputs"))
    checks = {
        "v1_row_has_colab_badge": "blob/main/tutorials/DIMER_FreshRetailNet_MultiModel_Classification_Workshop.ipynb" in readme,
        "v1_row_says_unverified": "unverified for Revision 2.1.0" in readme,
        "explicit_recommendation_which_to_use": bool(re.search(r"(use|start with|recommended|prefer)[^.\n]{0,80}(v2|guided edition)", readme, re.I)),
        "prose_claims_v2_saved_outputs_retained": "saved outputs are retained from the recorded run" in readme,
        "v2_code_cells_with_outputs_at_sha": v2_outputs,
        "v1_legacy_evidence_mentioned_in_readme": "legacy-classification-saved-outputs" in readme,
    }
    record("P12_readme_guidance", verdict="observed", summary=json.dumps(checks), checks=checks,
           basis="source inspection")


def main():
    for probe in (p01, p02, p03, p04, p05, p06, p07, p08, p09, p10, p11, p12):
        try:
            probe()
        except Exception as exc:  # noqa: BLE001
            RESULTS[probe.__name__] = {"verdict": "probe error", "summary": f"{type(exc).__name__}: {exc}",
                                       "trace": traceback.format_exc()[-1500:]}
            print(f"[{probe.__name__}] probe error: {exc}")
    RESULTS.pop("_ns_p04", None)
    RESULTS["_meta"] = {
        "repo_root": str(REPO), "reviewed_sha": "0434a026cf755071e89bc33c876e67040c2a614d",
        "notebook_blob": "6b8986dffb1af653b9129ae3ac2e005d76afc693",
        "python": sys.version.split()[0],
    }
    out = Path(__file__).with_name("results.json")
    out.write_text(json.dumps(RESULTS, indent=2, default=str), encoding="utf-8")
    print("wrote", out)


if __name__ == "__main__":
    main()
