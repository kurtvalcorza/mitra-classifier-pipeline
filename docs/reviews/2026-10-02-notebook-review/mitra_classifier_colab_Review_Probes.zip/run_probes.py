"""Review probes for tutorials/mitra_classifier_colab.ipynb (row 47, prefix MCC).

Direct CPU execution of the notebook's own code cells, in order, in one namespace, with the install cell
skipped (DIMER_NOTEBOOK_CI_PREINSTALLED=1) inside a read-only venv that already holds the notebook's exact pins
(autogluon.tabular 1.5.0, lightgbm 4.6.0, huggingface-hub 0.36.2; torch 2.9.1 CPU). The digest-verified
Mitra snapshot is pre-copied into the work directory, so stage_missing_files fetches nothing (the Hub download
is NOT exercised here). google.colab.files.upload is stubbed with in-memory payloads for the BYOD probes.
Form values are changed only by rewriting the cell's own `NAME = value  # @param` assignment line.

Usage: python run_probes.py NOTEBOOK WORKDIR RESULTS {default_and_active|byod|static}
"""
from __future__ import annotations

import contextlib
import io
import json
import os
import re
import sys
import time
import traceback
import types
import warnings
import zipfile
from pathlib import Path

NB, WORK, RESULTS, MODE = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), sys.argv[4]
REPO = NB.parent.parent
CELLS = [''.join(c['source']) for c in json.loads(NB.read_text(encoding='utf-8'))['cells']]
CODE = [i for i, c in enumerate(json.loads(NB.read_text(encoding='utf-8'))['cells']) if c['cell_type'] == 'code']
UPLOAD: dict[str, bytes] = {}
HOST_MEMORY_RATIO = 3.0


def save(key, value):
    data = json.loads(RESULTS.read_text(encoding='utf-8')) if RESULTS.exists() else {}
    data[key] = value
    RESULTS.write_text(json.dumps(data, indent=2, default=str), encoding='utf-8')


def set_param(src: str, name: str, value) -> str:
    pat = re.compile(rf'^{name} = .*?(  # @param.*)?$', re.M)
    assert pat.search(src), name
    return pat.sub(lambda m: f'{name} = {value!r}' + (m.group(1) or ''), src, count=1)


def run(ns, idx, params=None, label=None):
    src = CELLS[idx]
    params = dict(params or {})
    if idx == 13:  # host deviation: this review host had ~3.5 GB free RAM; AutoGluon's pre-fit estimate for Mitra is ~7.1 GB
        params.setdefault('MAX_MEMORY_USAGE_RATIO', HOST_MEMORY_RATIO)
    for k, v in params.items():
        src = set_param(src, k, v)
    out = io.StringIO()
    t0 = time.time()
    err = None
    with warnings.catch_warnings(record=True) as caught, contextlib.redirect_stdout(out), contextlib.redirect_stderr(out):
        warnings.simplefilter('always')
        try:
            exec(compile(src, f'cell{idx}', 'exec'), ns)
        except BaseException as exc:  # noqa: BLE001
            err = f'{type(exc).__name__}: {exc}'
    rec = {'cell': idx, 'label': label, 'seconds': round(time.time() - t0, 1), 'error': err,
           'stdout_tail': out.getvalue()[-2500:],
           'warnings': sorted({f'{w.category.__name__}: {str(w.message)[:160]}' for w in caught})}
    print(f'cell {idx} {label or ""} {rec["seconds"]}s err={err}', file=sys.__stdout__, flush=True)
    return rec


def setup():
    os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
    os.chdir(WORK)
    colab = types.ModuleType('google.colab')
    colab.files = types.SimpleNamespace(upload=lambda: dict(UPLOAD))
    google = types.ModuleType('google')
    google.colab = colab
    sys.modules['google'] = google
    sys.modules['google.colab'] = colab
    ns = {'__name__': '__main__'}
    recs = [run(ns, i) for i in (3, 5, 7)]
    return ns, recs


def default_and_active():
    ns, recs = setup()
    for i in CODE[3:]:
        recs.append(run(ns, i, label='default'))
    p = ns['pipe'].predictor
    mitra = p._trainer.load_model(p.model_best)
    ctx_rows = int(len(mitra.model.X)) if hasattr(mitra.model, 'X') else None
    meta = json.loads((Path(ns['active_path']) / 'tutorial_run_metadata.json').read_text(encoding='utf-8'))
    save('P1_default', {
        'cells': recs,
        'support_rows_after_validation': len(ns['train_data']),
        'mitra_in_context_rows': ctx_rows,
        'autogluon_val_rows': (lambda: int(len(p.load_data_internal('val')[0])))() if True else None,
        'run_metadata_train_rows_used': meta['train_rows_used'],
        'lightgbm_rf_fit_rows': len(ns['X_train_tree']),
        'metrics_table': ns['metrics_table'].round(4).to_dict(orient='records'),
        'holdout_rows': len(ns['holdout_data']),
        'outputs': sorted(os.listdir('outputs')),
        'device': ns['ACTIVE_MODEL'].device,
    })


def finetune_selection():
    """Cell 13 with RUN_FINE_TUNING=True, GPU check stubbed True, and the candidate's fit replaced by a stand-in
    that reuses the already-registered pretrained predictor (no second model in memory on this low-RAM host).
    Everything after the candidate fit is cell 13's own code."""
    ns, recs = setup()
    for i in (9, 11):
        recs.append(run(ns, i))
    import torch
    real_avail, real_cls = torch.cuda.is_available, ns['MitraClassificationPipeline']
    holder = {}

    class StandIn(real_cls):
        def fit(self, *a, **kw):
            self.predictor = holder['pipe'].predictor
            self.features = list(holder['pipe'].features)
            self.problem_type = holder['pipe'].problem_type
            return self

    orig_fit = real_cls.fit

    def pipe_fit(self, *a, **kw):
        holder['pipe'] = self
        return orig_fit(self, *a, **kw)

    real_cls.fit = pipe_fit
    torch.cuda.is_available = lambda: True
    ns['MitraClassificationPipeline'] = StandIn
    try:
        sel = run(ns, 13, {'RUN_FINE_TUNING': True}, label='fine-tune selection path, stand-in candidate')
    finally:
        torch.cuda.is_available = real_avail
        ns['MitraClassificationPipeline'] = real_cls
        real_cls.fit = orig_fit
    save('P2_finetune_selection_standin', {'setup': recs, 'cell13': sel})
    gate = run(ns, 13, {'RUN_FINE_TUNING': True}, label='fine-tune gate on CPU (real)')
    save('P2b_finetune_gate_cpu', gate)


def wine():
    """The documented next experiment (Sample: Wine), fresh process (host RAM), cells 9..19."""
    ns, recs = setup()
    out = [run(ns, 9, {'DATA_SOURCE': 'Sample: Wine'}, label='wine')]
    for i in CODE[4:]:
        out.append(run(ns, i, label='wine'))
    p = ns['pipe'].predictor
    mitra = p._trainer.load_model(p.model_best)
    save('P3_active_wine', {
        'cells': out,
        'classes': [str(c) for c in ns['CLASSES']], 'problem_type': ns['PROBLEM_TYPE'],
        'train_holdout_test': [len(ns['train_data']), len(ns['holdout_data']), len(ns['test_data'])],
        'mitra_in_context_rows': int(len(mitra.model.X)) if hasattr(mitra.model, 'X') else None,
        'metrics_table': ns['metrics_table'].round(4).to_dict(orient='records'),
        'holdout_rows': len(ns['holdout_data']),
    })


def zip_members(name):
    with zipfile.ZipFile(REPO / 'examples' / 'sample-data' / name) as zf:
        return {m: zf.read(m) for m in zf.namelist()}


def byod():
    ns, recs = setup()
    res = {'setup': recs}
    telco = zip_members('telco-customer-churn.zip')
    upload = {'USE_BYOD': True}
    # R1: pre-split Telco CSVs (as the Next-experiments text suggests), default TARGET_COLUMN left as 'target'.
    UPLOAD.clear(); UPLOAD.update(telco)
    res['R1_presplit_default_target'] = [run(ns, 9, {**upload, 'DATA_SOURCE': 'Upload pre-split train/val/test'}), run(ns, 11)]
    # R2: the archive itself uploaded (the text says "archives").
    UPLOAD.clear(); UPLOAD['telco-customer-churn.zip'] = (REPO / 'examples/sample-data/telco-customer-churn.zip').read_bytes()
    res['R2_zip_upload'] = run(ns, 9, {**upload, 'DATA_SOURCE': 'Upload pre-split train/val/test'})
    # R3: Upload CSV without USE_BYOD.
    res['R3_upload_without_use_byod'] = run(ns, 9, {'DATA_SOURCE': 'Upload CSV'})
    # R4: invalid single CSV: 11 classes.
    import pandas as pd
    bad = pd.DataFrame({'x': range(220), 'y': [i % 11 for i in range(220)]})
    UPLOAD.clear(); UPLOAD['eleven.csv'] = bad.to_csv(index=False).encode()
    res['R4_eleven_classes'] = run(ns, 9, {**upload, 'DATA_SOURCE': 'Upload CSV', 'TARGET_COLUMN': 'y'})
    # R5: valid pre-split Telco with TARGET_COLUMN='Churn', DROP_COLUMNS customerID if present, full downstream path.
    UPLOAD.clear(); UPLOAD.update(telco)
    header = telco['train.csv'].decode().splitlines()[0]
    drops = 'customerID' if 'customerID' in header else ''
    r5 = [run(ns, 9, {**upload, 'DATA_SOURCE': 'Upload pre-split train/val/test', 'TARGET_COLUMN': 'Churn', 'DROP_COLUMNS': drops}, label='telco')]
    for i in CODE[4:]:
        r5.append(run(ns, i, label='telco'))
    res['R5_presplit_telco_full'] = {'cells': r5, 'header': header[:300],
                                     'metrics_table': ns['metrics_table'].round(4).to_dict(orient='records') if 'metrics_table' in ns else None,
                                     'overlaps': ns.get('overlaps')}
    # R6: new-data inference via NEW_DATA_PATH: valid rows (test features without target), then a CSV missing a feature.
    test = pd.read_csv(io.BytesIO(telco['test.csv']))
    good = test.drop(columns=['Churn']).head(20)
    good.to_csv('new_rows.csv', index=False)
    res['R6_new_data_valid'] = run(ns, 17, {'RUN_NEW_DATA_INFERENCE': True, 'NEW_DATA_PATH': 'new_rows.csv'})
    good.drop(columns=[ns['FEATURE_COLUMNS'][0]]).to_csv('new_rows_missing.csv', index=False)
    res['R6b_new_data_missing_feature'] = run(ns, 17, {'RUN_NEW_DATA_INFERENCE': True, 'NEW_DATA_PATH': 'new_rows_missing.csv'})
    # R7: single-CSV upload path (Upload CSV): Adult train.csv only.
    adult = zip_members('adult-census-income.zip')
    UPLOAD.clear(); UPLOAD['adult.csv'] = adult['train.csv']
    r7 = [run(ns, 9, {**upload, 'DATA_SOURCE': 'Upload CSV', 'TARGET_COLUMN': 'class'}, label='adult single csv')]
    for i in (11, 13):
        r7.append(run(ns, i, label='adult single csv'))
    res['R7_single_csv_adult'] = {'cells': r7, 'test_data_is_none': ns.get('test_data') is None,
                                  'metrics_table': ns['metrics_table'].round(4).to_dict(orient='records') if 'metrics_table' in ns else None}
    save('P4_byod', res)


def static():
    nb = json.loads(NB.read_text(encoding='utf-8'))
    allsrc = '\n'.join(CELLS)
    md = '\n'.join(''.join(c['source']) for c in nb['cells'] if c['cell_type'] == 'markdown')
    save('S_static', {
        'cells': len(nb['cells']), 'code_cells': CODE,
        'declared_spec': nb['metadata']['dimer']['notebook_spec'], 'mode': nb['metadata']['dimer']['notebook_mode'],
        'import_math_anywhere': bool(re.search(r'^\s*import math|^\s*from math', allsrc, re.M)),
        'math_uses': [i for i, s in enumerate(CELLS) if 'math.' in s],
        'collapsed_or_title_cells': [i for i, c in enumerate(nb['cells']) if c['cell_type'] == 'code' and (c.get('metadata', {}).get('cellView') == 'form' or c.get('metadata', {}).get('jupyter', {}).get('source_hidden'))],
        'guided_markers': {k: (k.lower() in md.lower()) for k in ('How to use', 'Expected result', 'What to notice', 'Predict', 'Checkpoint', 'Glossary', 'Troubleshooting', 'Infrastructure', 'Input →', 'conclusion')},
        'reviewer_facing_open_decision_sentence': 'should treat that as an open decision' in md,
        'eval15_cited_for_same_rows': 'same partitions (EVAL15)' in md,
        'restart_guard_present': 'Restart the runtime, then rerun from the top' in allsrc,
        'uv_used': 'uv venv' in allsrc,
    })


{'default_and_active': default_and_active, 'finetune_selection': finetune_selection, 'wine': wine, 'byod': byod, 'static': static}[MODE]()
